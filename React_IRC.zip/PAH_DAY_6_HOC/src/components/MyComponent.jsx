import React from 'react';

const MyComponent = () => {
    return (
        <div>
            <h1>Hello, I'm the wrapped component!</h1>
        </div>
    );
};

export default MyComponent;
