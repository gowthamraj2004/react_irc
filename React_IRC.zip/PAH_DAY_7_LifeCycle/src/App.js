import React from 'react';
import './assets/css/App.css';
import Lifecycle from './components/LifeCycle';

function App() {

  return (
    <div className="App">
      <Lifecycle />
    </div>
  );
}

export default App;
