import React from 'react';
import './assets/css/App.css';
import Greeting from './components/Greeting';

function App() {
  return (
    <div className="App">
      <Greeting />
    </div>
  );
}

export default App;
