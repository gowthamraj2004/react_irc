import React from 'react';
import './assets/css/App.css';
import CustomCard from './components/CustomCard';

function App() {

  return (
    <div className="App">
      <CustomCard />
    </div>
  );
}

export default App;
